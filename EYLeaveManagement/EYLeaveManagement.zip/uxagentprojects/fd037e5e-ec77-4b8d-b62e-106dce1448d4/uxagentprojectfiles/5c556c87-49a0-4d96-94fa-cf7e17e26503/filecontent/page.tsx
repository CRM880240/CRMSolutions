import React, { useEffect, useState, useCallback } from "react";
import {
    Button,
    Text,
    DataGrid,
    DataGridHeader,
    DataGridBody,
    DataGridRow,
    DataGridCell,
    DataGridHeaderCell,
    TableCellLayout,
    createTableColumn,
    makeStyles,
    tokens,
    Spinner,
    Toast,
    Toaster,
    useToastController
} from "@fluentui/react-components";
import { CheckmarkCircle20Regular, DismissCircle20Regular, ArrowDownload20Regular, ErrorCircle20Regular, DocumentCheckmark24Regular, Clock24Regular, CheckmarkCircle24Regular, DismissCircle24Regular } from "@fluentui/react-icons";
import type { GeneratedComponentProps, ReadableTableRow, QueryTableOptions } from "./RuntimeTypes";
import { cr4f0_leavemanagement, cr4f0_leavemanagement_cr4f0_leavestatus } from "./RuntimeTypes";

const EY_YELLOW = "#FFD700";
const EY_BLACK = "#000000";

const useStyles = makeStyles({
    container: { display: "flex", flexDirection: "column", width: "100%", height: "100%", boxSizing: "border-box", backgroundColor: tokens.colorNeutralBackground1 },
    header: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 20px", backgroundColor: EY_BLACK, color: "#FFFFFF", gap: tokens.spacingHorizontalM },
    headerLeft: { display: "flex", alignItems: "center", gap: tokens.spacingHorizontalM },
    logo: { width: "48px", height: "48px", objectFit: "contain" },
    headerTitle: { fontSize: "1.5rem", fontWeight: 600, color: "#FFFFFF" },
    contentArea: { flex: 1, padding: tokens.spacingHorizontalM, backgroundColor: "#F6F6F6", overflowY: "auto" },
    summaryCardsContainer: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: tokens.spacingHorizontalM, marginBottom: tokens.spacingVerticalM },
    summaryCard: { backgroundColor: "#FFFFFF", borderRadius: tokens.borderRadiusMedium, boxShadow: tokens.shadow2, padding: tokens.spacingHorizontalM, display: "flex", alignItems: "center", gap: tokens.spacingHorizontalM },
    cardIcon: { fontSize: "48px", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 },
    cardContent: { display: "flex", flexDirection: "column", justifyContent: "center" },
    cardLabel: { fontSize: "0.875rem", fontWeight: 500, color: "#666666" },
    cardValue: { fontSize: "1.75rem", fontWeight: "bold", color: EY_BLACK },
    totalLeavesCard: { borderLeft: `4px solid ${EY_YELLOW}` },
    pendingCard: { borderLeft: "4px solid #FFB81C" },
    approvedCard: { borderLeft: "4px solid #107C10" },
    rejectedCard: { borderLeft: "4px solid #D13438" },
    gridSection: { flex: 1, backgroundColor: "#FFFFFF", borderRadius: tokens.borderRadiusMedium, boxShadow: tokens.shadow4, padding: tokens.spacingHorizontalM },
    gridHeaderActions: { display: "flex", justifyContent: "flex-end", marginBottom: tokens.spacingVerticalS },
    gridContainer: { marginTop: tokens.spacingVerticalS, overflow: "auto", height: "100%" },
    approveBtn: { backgroundColor: EY_YELLOW, color: EY_BLACK, fontWeight: "bold", "&:hover": { backgroundColor: "#FFC300" } },
    rejectBtn: { backgroundColor: "#FFFFFF", border: `1px solid ${EY_BLACK}`, color: EY_BLACK, "&:hover": { backgroundColor: "#F0F0F0" } },
    downloadBtn: { backgroundColor: EY_YELLOW, color: EY_BLACK, fontWeight: "bold", "&:hover": { backgroundColor: "#FFC300" } },
    dataGridHeader: { backgroundColor: EY_YELLOW, fontWeight: "bold", color: EY_BLACK },
    invalidDateRow: { backgroundColor: "#FFE0E0" },
    invalidDateText: { color: "#D13438", fontWeight: "bold" }
});

const GeneratedComponent: React.FC<GeneratedComponentProps> = ({ dataApi }) => {
    const styles = useStyles();
    const [leaveRequests, setLeaveRequests] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [currentUserId, setCurrentUserId] = useState<string>("");
    const [leaveStats, setLeaveStats] = useState({ total: 0, pending: 0, approved: 0, rejected: 0 });
    const { dispatchToast } = useToastController();

    const fetchCurrentUser = useCallback(() => {
        try {
            const id = Xrm.Utility.getGlobalContext().userSettings.userId.replace(/[{}]/g, "");
            setCurrentUserId(id);
        } catch (err) {
            console.error("Failed to get current user:", err);
        }
    }, []);

    const fetchLeaveRequests = useCallback(async () => {
        if (!currentUserId) return;

        setLoading(true);
        try {
            const userQuery: QueryTableOptions<any> = {
                select: ["systemuserid", "fullname"],
                filter: `_parentsystemuserid_value eq '${currentUserId}'`
            };
            const userResult = await dataApi.queryTable("systemuser", userQuery);

            if (userResult.rows.length === 0) {
                setLeaveRequests([]);
                setLeaveStats({ total: 0, pending: 0, approved: 0, rejected: 0 });
                return;
            }

            const userIds = userResult.rows.map(u => `'${u.systemuserid}'`);

            // Fetch all leave requests regardless of status for statistics
            const allLeaveQuery: QueryTableOptions<cr4f0_leavemanagement> = {
                select: [
                    "_ownerid_value",
                    "ownerid",
                    "cr4f0_leavemanagementid",
                    "cr4f0_leavereason",
                    "cr4f0_leavestatus",
                    "cr4f0_leavetype",
                    "cr4f0_leavesubmitted",
                    "cr4f0_leavestart",
                    "cr4f0_leaveend"
                ],
                filter: `ownerid in (${userIds.join(",")})`,
                orderBy: "cr4f0_leavesubmitted desc"
            };

            const allLeaveResult = await dataApi.queryTable("cr4f0_leavemanagement", allLeaveQuery);

            // Calculate statistics
            const total = allLeaveResult.rows.length;
            const pending = allLeaveResult.rows.filter(r => r.cr4f0_leavestatus === cr4f0_leavemanagement_cr4f0_leavestatus.Pending).length;
            const approved = allLeaveResult.rows.filter(r => r.cr4f0_leavestatus === cr4f0_leavemanagement_cr4f0_leavestatus.Approved).length;
            const rejected = allLeaveResult.rows.filter(r => r.cr4f0_leavestatus === cr4f0_leavemanagement_cr4f0_leavestatus.Rejected).length;

            setLeaveStats({ total, pending, approved, rejected });

            // Display only pending requests in the grid
            const pendingRows = allLeaveResult.rows.filter(
                r => r.cr4f0_leavestatus === cr4f0_leavemanagement_cr4f0_leavestatus.Pending
            );

            const finalRows = pendingRows.map(r => ({
                ...r,
                employeeName: r["_ownerid_value@OData.Community.Display.V1.FormattedValue"] || ""
            }));

            setLeaveRequests(finalRows);

        } catch (err) {
            console.error("Error fetching leave requests:", err);
            setLeaveRequests([]);
            setLeaveStats({ total: 0, pending: 0, approved: 0, rejected: 0 });
        } finally {
            setLoading(false);
        }
    }, [currentUserId, dataApi]);

    useEffect(() => fetchCurrentUser(), []);
    useEffect(() => fetchLeaveRequests(), [fetchLeaveRequests]);

    const isValidDateRange = (startDate: string, endDate: string): boolean => {
        if (!startDate || !endDate) return false;
        const start = new Date(startDate);
        const end = new Date(endDate);
        return end >= start;
    };

    const handleApprove = async (id: string) => {
        const leaveRequest = leaveRequests.find(r => r.cr4f0_leavemanagementid === id);
        
        if (!isValidDateRange(leaveRequest?.cr4f0_leavestart, leaveRequest?.cr4f0_leaveend)) {
            dispatchToast(
                <Toast>
                    <div>
                        <ErrorCircle20Regular style={{ color: "#D13438", marginRight: "8px" }} />
                        Leave end date cannot be less than leave start date
                    </div>
                </Toast>,
                { intent: "error", timeout: 5000 }
            );
            return;
        }

        await dataApi.updateRow("cr4f0_leavemanagement", id, {
            cr4f0_leavestatus: cr4f0_leavemanagement_cr4f0_leavestatus.Approved
        });
        fetchLeaveRequests();
    };

    const handleReject = async (id: string) => {
        await dataApi.updateRow("cr4f0_leavemanagement", id, {
            cr4f0_leavestatus: cr4f0_leavemanagement_cr4f0_leavestatus.Rejected
        });
        fetchLeaveRequests();
    };

    const handleDownloadCSV = () => {
        if (leaveRequests.length === 0) return;

        const headers = ["Employee", "Leave Type", "Reason", "Submitted Date", "Status"];
        const rows = leaveRequests.map(item => [
            `"${item.employeeName}"`,
            `"${item["cr4f0_leavetype@OData.Community.Display.V1.FormattedValue"]}"`,
            `"${item.cr4f0_leavereason}"`,
            `"${new Date(item.cr4f0_leavesubmitted).toLocaleDateString()}"`,
            `"${item["cr4f0_leavestatus@OData.Community.Display.V1.FormattedValue"]}"`
        ]);

        const csvContent = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);

        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", "leave_requests.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const columns = [
        createTableColumn<any>({
            columnId: "employee",
            renderHeaderCell: () => <span className={styles.dataGridHeader}>Employee</span>,
            renderCell: item => <TableCellLayout>{item.employeeName}</TableCellLayout>
        }),
        createTableColumn<any>({
            columnId: "type",
            renderHeaderCell: () => <span className={styles.dataGridHeader}>Leave Type</span>,
            renderCell: item => <TableCellLayout>{item["cr4f0_leavetype@OData.Community.Display.V1.FormattedValue"]}</TableCellLayout>
        }),
        createTableColumn<any>({
            columnId: "reason",
            renderHeaderCell: () => <span className={styles.dataGridHeader}>Reason</span>,
            renderCell: item => <TableCellLayout>{item.cr4f0_leavereason}</TableCellLayout>
        }),
        createTableColumn<any>({
            columnId: "submitted",
            renderHeaderCell: () => <span className={styles.dataGridHeader}>Submitted</span>,
            renderCell: item => (
                <TableCellLayout>
                    {new Date(item.cr4f0_leavesubmitted).toLocaleDateString()}
                </TableCellLayout>
            )
        }),
        createTableColumn<any>({
            columnId: "status",
            renderHeaderCell: () => <span className={styles.dataGridHeader}>Status</span>,
            renderCell: item => <TableCellLayout>{item["cr4f0_leavestatus@OData.Community.Display.V1.FormattedValue"]}</TableCellLayout>
        }),
        createTableColumn<any>({
            columnId: "actions",
            renderHeaderCell: () => <span className={styles.dataGridHeader}>Actions</span>,
            renderCell: item => (
                <div style={{ display: "flex", gap: "8px" }}>
                    <Button size="small" className={styles.approveBtn} icon={<CheckmarkCircle20Regular />} onClick={() => handleApprove(item.cr4f0_leavemanagementid)}>
                        Approve
                    </Button>
                    <Button size="small" className={styles.rejectBtn} icon={<DismissCircle20Regular />} onClick={() => handleReject(item.cr4f0_leavemanagementid)}>
                        Reject
                    </Button>
                </div>
            )
        })
    ];

    return (
        <div className={styles.container}>
            <div className={styles.header}>
                <div className={styles.headerLeft}>
                    <img
                        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYGsuJ60Nb5AyNh3H2PVCuLHF4Ft24yNMruQ&s"
                        alt="EY Logo"
                        className={styles.logo}
                    />
                    <Text as="h1" className={styles.headerTitle}>Manager Leave Approval</Text>
                </div>
                <Button className={styles.downloadBtn} icon={<ArrowDownload20Regular />} onClick={handleDownloadCSV} aria-label="Download leave requests as CSV">
                    Download CSV
                </Button>
            </div>

            <div className={styles.contentArea}>
                <div className={styles.summaryCardsContainer}>
                    <div className={`${styles.summaryCard} ${styles.totalLeavesCard}`}>
                        <div className={styles.cardIcon}>
                            <DocumentCheckmark24Regular style={{ fontSize: "48px", color: EY_YELLOW }} />
                        </div>
                        <div className={styles.cardContent}>
                            <div className={styles.cardLabel}>Total Leaves</div>
                            <div className={styles.cardValue}>{leaveStats.total}</div>
                        </div>
                    </div>

                    <div className={`${styles.summaryCard} ${styles.pendingCard}`}>
                        <div className={styles.cardIcon}>
                            <Clock24Regular style={{ fontSize: "48px", color: "#FFB81C" }} />
                        </div>
                        <div className={styles.cardContent}>
                            <div className={styles.cardLabel}>Pending</div>
                            <div className={styles.cardValue}>{leaveStats.pending}</div>
                        </div>
                    </div>

                    <div className={`${styles.summaryCard} ${styles.approvedCard}`}>
                        <div className={styles.cardIcon}>
                            <CheckmarkCircle24Regular style={{ fontSize: "48px", color: "#107C10" }} />
                        </div>
                        <div className={styles.cardContent}>
                            <div className={styles.cardLabel}>Approved</div>
                            <div className={styles.cardValue}>{leaveStats.approved}</div>
                        </div>
                    </div>

                    <div className={`${styles.summaryCard} ${styles.rejectedCard}`}>
                        <div className={styles.cardIcon}>
                            <DismissCircle24Regular style={{ fontSize: "48px", color: "#D13438" }} />
                        </div>
                        <div className={styles.cardContent}>
                            <div className={styles.cardLabel}>Rejected</div>
                            <div className={styles.cardValue}>{leaveStats.rejected}</div>
                        </div>
                    </div>
                </div>

                <section className={styles.gridSection}>
                    <Text size={500} weight="semibold" style={{ color: EY_BLACK }}>
                        Pending Leave Requests
                    </Text>

                    <div className={styles.gridContainer}>
                        {loading ? (
                            <Spinner label="Loading leave requests..." />
                        ) : (
                            <DataGrid items={leaveRequests} columns={columns} getRowId={item => item.cr4f0_leavemanagementid} focusMode="composite">
                                <DataGridHeader>
                                    <DataGridRow>
                                        {({ renderHeaderCell }) => (
                                            <DataGridHeaderCell>{renderHeaderCell()}</DataGridHeaderCell>
                                        )}
                                    </DataGridRow>
                                </DataGridHeader>

                                <DataGridBody>
                                    {({ item }) => (
                                        <DataGridRow key={item.cr4f0_leavemanagementid}>
                                            {({ renderCell }) => (
                                                <DataGridCell>{renderCell(item)}</DataGridCell>
                                            )}
                                        </DataGridRow>
                                    )}
                                </DataGridBody>
                            </DataGrid>
                        )}
                    </div>
                </section>
            </div>
        </div>
    );
};

export default GeneratedComponent;