import React, { useEffect, useState, useRef } from "react";
import {
    Button,
    Text,
    Input,
    Dropdown,
    Option,
    Dialog,
    DialogSurface,
    DialogBody,
    DialogTitle,
    DialogContent,
    DialogActions,
    makeStyles,
    tokens,
    DataGrid,
    DataGridHeader,
    DataGridBody,
    DataGridRow,
    DataGridCell,
    DataGridHeaderCell,
    TableCellLayout,
    createTableColumn
} from "@fluentui/react-components";
import { AddRegular, EditRegular, DeleteRegular } from "@fluentui/react-icons";
import * as d3 from "d3";
import type {
    GeneratedComponentProps,
    ReadableTableRow,
    QueryTableOptions,
    WritableTableRow
} from "./RuntimeTypes";
import type { cr4f0_leavemanagement } from "./RuntimeTypes";

const useStyles = makeStyles({
    container: {
        display: "flex",
        flexDirection: "column",
        width: "100%",
        height: "100vh",
        boxSizing: "border-box",
        backgroundColor: "#fff",
        overflowY: "auto"
    },
    header: {
        backgroundColor: "#000",
        color: "#FFD500",
        padding: "16px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        flexShrink: 0
    },
    headerLeft: { display: "flex", alignItems: "center", gap: "12px" },
    logo: { height: "40px", width: "auto", objectFit: "contain" },
    headerTitle: { fontSize: tokens.fontSizeHero500, fontWeight: tokens.fontWeightSemibold, color: "#FFD500" },
    cardsContainer: {
        display: "flex",
        flexDirection: "row",
        gap: "16px",
        padding: "16px",
        backgroundColor: "#fafafa",
        justifyContent: "space-between",
        flexShrink: 0
    },
    card: {
        flex: 1,
        minWidth: 0,
        backgroundColor: "#fff",
        border: `1px solid ${tokens.colorNeutralStroke1}`,
        borderRadius: tokens.borderRadiusMedium,
        boxShadow: tokens.shadow4,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "12px",
        textAlign: "center",
        transition: "transform 0.2s ease, box-shadow 0.2s ease",
        "&:hover": {
            transform: "scale(1.03)",
            boxShadow: "0 4px 12px rgba(255, 213, 0, 0.6)"
        }
    },
    cardImage: {
        width: "100%",
        maxHeight: "120px",
        objectFit: "cover",
        borderRadius: tokens.borderRadiusSmall,
        marginBottom: "8px"
    },
    cardTitle: { fontSize: tokens.fontSizeBase400, fontWeight: tokens.fontWeightSemibold, marginBottom: "4px" },
    cardValue: { fontSize: tokens.fontSizeHero700, fontWeight: tokens.fontWeightBold, color: "#000" },
    dashboardContainer: {
        display: "flex",
        flexWrap: "wrap",
        gap: "16px",
        padding: "16px",
        backgroundColor: "#fafafa",
        justifyContent: "center",
        alignItems: "center",
        flexShrink: 0
    },
    chartCard: {
        flex: "1 1 300px",
        minWidth: "300px",
        backgroundColor: "#fff",
        border: `1px solid ${tokens.colorNeutralStroke1}`,
        borderRadius: tokens.borderRadiusMedium,
        padding: "12px",
        boxShadow: tokens.shadow4,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center"
    },
    filterBar: {
        display: "flex",
        gap: "12px",
        padding: "12px",
        alignItems: "center",
        flexWrap: "wrap",
        backgroundColor: "#f5f5f5",
        flexShrink: 0
    },
    gridContainer: {
        flex: 1,
        overflowY: "auto",
        padding: "12px",
        backgroundColor: "#fff",
        boxSizing: "border-box"
    },
    addButton: { marginLeft: "auto" },
    formField: { marginBottom: "12px", display: "flex", flexDirection: "column", gap: "4px" },
    fileUploadContainer: {
        padding: "8px",
        border: `1px dashed ${tokens.colorNeutralStroke1}`,
        borderRadius: tokens.borderRadiusMedium,
        textAlign: "center",
        backgroundColor: tokens.colorNeutralBackground3
    },
    uploadedFile: {
        marginTop: "6px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        backgroundColor: tokens.colorNeutralBackground1,
        padding: "4px 8px",
        borderRadius: tokens.borderRadiusSmall,
        border: `1px solid ${tokens.colorNeutralStroke1}`
    }
});

const GeneratedComponent: React.FC<GeneratedComponentProps> = ({ dataApi }) => {
    const styles = useStyles();
    const fileInputRef = useRef<HTMLInputElement>(null);

    const [leaveData, setLeaveData] = useState<ReadableTableRow<cr4f0_leavemanagement>[]>([]);
    const [statusFilter, setStatusFilter] = useState<string>("");
    const [typeFilter, setTypeFilter] = useState<string>("");
    const [statusOptions, setStatusOptions] = useState<{ label: string; value: number }[]>([]);
    const [typeOptions, setTypeOptions] = useState<{ label: string; value: number }[]>([]);
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [uploadedFile, setUploadedFile] = useState<File | null>(null);
    const [currentUserId, setCurrentUserId] = useState<string>("");
    const [editingLeaveId, setEditingLeaveId] = useState<string | null>(null);
    const [isDeleteSuccessDialogOpen, setIsDeleteSuccessDialogOpen] = useState(false);
    const [isDeleteConfirmDialogOpen, setIsDeleteConfirmDialogOpen] = useState(false);
    const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);

    const [formData, setFormData] = useState<WritableTableRow<cr4f0_leavemanagement>>({
        cr4f0_leavemanagement1: "",
        cr4f0_leavereason: "",
        cr4f0_leavestatus: 810760000,
        cr4f0_leavetype: 810760000,
        cr4f0_leavestartdate: new Date(),
        cr4f0_leaveenddate: new Date()
    });

    const typeChartRef = useRef<SVGSVGElement>(null);
    const statusChartRef = useRef<SVGSVGElement>(null);

    useEffect(() => {
        const fetchChoices = async () => {
            const statusChoices = await dataApi.getChoices("cr4f0_leavemanagement-cr4f0_leavestatus");
            const typeChoices = await dataApi.getChoices("cr4f0_leavemanagement-cr4f0_leavetype");
            setStatusOptions(statusChoices);
            setTypeOptions(typeChoices);
        };
        fetchChoices();
    }, [dataApi]);

    const fetchLeaves = async () => {
        if (!currentUserId) return;
        const query: QueryTableOptions<cr4f0_leavemanagement> = {
            select: ["cr4f0_leavemanagement1", "cr4f0_leavereason", "cr4f0_leavestatus", "cr4f0_leavetype", "cr4f0_leavestartdate", "cr4f0_leaveenddate", "_ownerid_value"],
            orderBy: "cr4f0_leavestartdate desc",
            filter: `_ownerid_value eq ${currentUserId}`
        };
        if (statusFilter) query.filter += ` and cr4f0_leavestatus eq ${statusFilter}`;
        if (typeFilter) query.filter += ` and cr4f0_leavetype eq ${typeFilter}`;
        const result = await dataApi.queryTable("cr4f0_leavemanagement", query);
        setLeaveData(result.rows);
    };

    useEffect(() => { fetchLeaves(); }, [statusFilter, typeFilter, currentUserId]);

    useEffect(() => {
        try {
            const userId = (Xrm.Utility.getGlobalContext().userSettings.userId || "").replace(/[{}]/g, "");
            setCurrentUserId(userId);
        } catch (error) { console.error("Error fetching current user:", error); }
    }, []);

    const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => { if (event.target.files?.length) setUploadedFile(event.target.files[0]); };
    const handleRemoveFile = () => { setUploadedFile(null); if (fileInputRef.current) fileInputRef.current.value = ""; };

    const handleAddOrUpdateLeave = async () => {
        const leavePayload = { ...formData };
        if (uploadedFile) leavePayload.cr4f0_leavereason += ` (Doc: ${uploadedFile.name})`;
        if (editingLeaveId) {
            await dataApi.updateRow("cr4f0_leavemanagement", editingLeaveId, leavePayload);
        } else {
            await dataApi.createRow("cr4f0_leavemanagement", leavePayload);
        }
        setIsDialogOpen(false);
        setUploadedFile(null);
        setEditingLeaveId(null);
        setFormData({ cr4f0_leavemanagement1: "", cr4f0_leavereason: "", cr4f0_leavestatus: 810760000, cr4f0_leavetype: 810760000, cr4f0_leavestartdate: new Date(), cr4f0_leaveenddate: new Date() });
        fetchLeaves();
    };

    const handleEdit = (item: ReadableTableRow<cr4f0_leavemanagement>) => {
        setEditingLeaveId(item.cr4f0_leavemanagementid);
        setFormData({
            cr4f0_leavemanagement1: item.cr4f0_leavemanagement1 || "",
            cr4f0_leavereason: item.cr4f0_leavereason || "",
            cr4f0_leavestatus: item.cr4f0_leavestatus,
            cr4f0_leavetype: item.cr4f0_leavetype,
            cr4f0_leavestartdate: item.cr4f0_leavestartdate ? new Date(item.cr4f0_leavestartdate) : new Date(),
            cr4f0_leaveenddate: item.cr4f0_leaveenddate ? new Date(item.cr4f0_leaveenddate) : new Date()
        });
        setIsDialogOpen(true);
    };

    const handleDeleteClick = (id: string) => {
        setDeleteTargetId(id);
        setIsDeleteConfirmDialogOpen(true);
    };

    const confirmDelete = async () => {
        if (deleteTargetId) {
            await dataApi.deleteRow("cr4f0_leavemanagement", deleteTargetId);
            await fetchLeaves();
            setIsDeleteConfirmDialogOpen(false);
            setDeleteTargetId(null);
            setIsDeleteSuccessDialogOpen(true);
        }
    };

    const handleDownloadCSV = () => {
        if (!leaveData.length) {
            alert("No leave data available to download.");
            return;
        }
        const headers = ["Leave Name", "Type", "Status", "Reason", "Start Date", "End Date"];
        const rows = leaveData.map(item => [
            `"${item.cr4f0_leavemanagement1 || ""}"`,
            `"${item["cr4f0_leavetype@OData.Community.Display.V1.FormattedValue"] || ""}"`,
            `"${item["cr4f0_leavestatus@OData.Community.Display.V1.FormattedValue"] || ""}"`,
            `"${item.cr4f0_leavereason || ""}"`,
            `"${item.cr4f0_leavestartdate ? new Date(item.cr4f0_leavestartdate).toLocaleDateString() : ""}"`,
            `"${item.cr4f0_leaveenddate ? new Date(item.cr4f0_leaveenddate).toLocaleDateString() : ""}"`
        ]);
        const csvContent = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", "leave_requests.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const totalLeaves = leaveData.length;
    const pendingLeaves = leaveData.filter(l => l.cr4f0_leavestatus === 810760000).length;
    const approvedLeaves = leaveData.filter(l => l.cr4f0_leavestatus === 810760001).length;
    const rejectedLeaves = leaveData.filter(l => l.cr4f0_leavestatus === 810760002).length;

    useEffect(() => {
        if (!leaveData.length) return;

        const typeCounts = d3.rollup(leaveData, v => v.length, d => d["cr4f0_leavetype@OData.Community.Display.V1.FormattedValue"] || "Unknown");
        const typeData = Array.from(typeCounts, ([key, value]) => ({ key, value }));

        const width = 300, height = 300;
        const margin = { top: 20, right: 20, bottom: 40, left: 40 };

        const svgType = d3.select(typeChartRef.current);
        svgType.selectAll("*").remove();

        const x = d3.scaleBand().domain(typeData.map(d => d.key)).range([margin.left, width - margin.right]).padding(0.1);
        const y = d3.scaleLinear().domain([0, d3.max(typeData, d => d.value) || 1]).nice().range([height - margin.bottom, margin.top]);

        const colorScale = d3.scaleOrdinal<string>().domain(typeData.map(d => d.key)).range(d3.schemeCategory10);

        const gType = svgType.attr("width", width).attr("height", height);
        gType.append("g").selectAll("rect")
            .data(typeData)
            .enter()
            .append("rect")
            .attr("x", d => x(d.key)!)
            .attr("y", d => y(d.value))
            .attr("height", d => y(0) - y(d.value))
            .attr("width", x.bandwidth())
            .attr("fill", d => colorScale(d.key));

        gType.append("g").attr("transform", `translate(0,${height - margin.bottom})`).call(d3.axisBottom(x));
        gType.append("g").attr("transform", `translate(${margin.left},0)`).call(d3.axisLeft(y));

        const statusCounts = d3.rollup(leaveData, v => v.length, d => d["cr4f0_leavestatus@OData.Community.Display.V1.FormattedValue"] || "Unknown");
        const statusData = Array.from(statusCounts, ([key, value]) => ({ key, value }));

        const svgStatus = d3.select(statusChartRef.current);
        svgStatus.selectAll("*").remove();

        const xStatus = d3.scaleBand().domain(statusData.map(d => d.key)).range([margin.left, width - margin.right]).padding(0.1);
        const yStatus = d3.scaleLinear().domain([0, d3.max(statusData, d => d.value) || 1]).nice().range([height - margin.bottom, margin.top]);

        const gStatus = svgStatus.attr("width", width).attr("height", height);
        gStatus.append("g").selectAll("rect")
            .data(statusData)
            .enter()
            .append("rect")
            .attr("x", d => xStatus(d.key)!)
            .attr("y", d => yStatus(d.value))
            .attr("height", d => yStatus(0) - yStatus(d.value))
            .attr("width", xStatus.bandwidth())
            .attr("fill", "#0078D4");

        gStatus.append("g").attr("transform", `translate(0,${height - margin.bottom})`).call(d3.axisBottom(xStatus));
        gStatus.append("g").attr("transform", `translate(${margin.left},0)`).call(d3.axisLeft(yStatus));
    }, [leaveData]);

    const columns = [
        createTableColumn<ReadableTableRow<cr4f0_leavemanagement>>({ columnId: "cr4f0_leavemanagement1", renderHeaderCell: () => "Leave Name", renderCell: (item) => <TableCellLayout>{item.cr4f0_leavemanagement1}</TableCellLayout> }),
        createTableColumn({ columnId: "cr4f0_leavetype", renderHeaderCell: () => "Type", renderCell: (item) => <TableCellLayout>{item["cr4f0_leavetype@OData.Community.Display.V1.FormattedValue"]}</TableCellLayout> }),
        createTableColumn({ columnId: "cr4f0_leavestatus", renderHeaderCell: () => "Status", renderCell: (item) => <TableCellLayout>{item["cr4f0_leavestatus@OData.Community.Display.V1.FormattedValue"]}</TableCellLayout> }),
        createTableColumn({ columnId: "cr4f0_leavereason", renderHeaderCell: () => "Reason", renderCell: (item) => <TableCellLayout>{item.cr4f0_leavereason}</TableCellLayout> }),
        createTableColumn({ columnId: "cr4f0_leavestartdate", renderHeaderCell: () => "Start Date", renderCell: (item) => <TableCellLayout>{new Date(item.cr4f0_leavestartdate).toLocaleDateString()}</TableCellLayout> }),
        createTableColumn({ columnId: "cr4f0_leaveenddate", renderHeaderCell: () => "End Date", renderCell: (item) => <TableCellLayout>{new Date(item.cr4f0_leaveenddate).toLocaleDateString()}</TableCellLayout> }),
        createTableColumn({ columnId: "edit", renderHeaderCell: () => "Edit", renderCell: (item) => <Button appearance="subtle" icon={<EditRegular />} onClick={() => handleEdit(item)} aria-label="Edit Leave" /> }),
        createTableColumn({ columnId: "delete", renderHeaderCell: () => "Delete", renderCell: (item) => <Button appearance="subtle" icon={<DeleteRegular />} onClick={() => handleDeleteClick(item.cr4f0_leavemanagementid)} aria-label="Delete Leave" /> })
    ];

    const formatDateForInput = (date: Date) => {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
    };

    return (
        <div className={styles.container}>
            <header className={styles.header}>
                <div className={styles.headerLeft}>
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYGsuJ60Nb5AyNh3H2PVCuLHF4Ft24yNMruQ&s" alt="EY Logo" className={styles.logo} />
                    <Text className={styles.headerTitle}>Leave Request Management</Text>
                </div>
            </header>

            {/* Summary Cards */}
            <div className={styles.cardsContainer}>
                <div className={styles.card}>
                    <img src="https://cdn.hubblecontent.osi.office.net/m365content/publish/e2621efa-f7ef-430d-bfa0-4981f87a0687/thumbnails/xxlarge.jpg" alt="Total Leaves" className={styles.cardImage} />
                    <Text className={styles.cardTitle}>Total Leaves</Text>
                    <Text className={styles.cardValue}>{totalLeaves}</Text>
                </div>
                <div className={styles.card}>
                    <img src="https://cdn.hubblecontent.osi.office.net/m365content/publish/ea0ab5b8-97c4-45a2-aa20-c23fe5d9ebe5/thumbnails/xxlarge.jpg" alt="Pending Leaves" className={styles.cardImage} />
                    <Text className={styles.cardTitle}>Pending</Text>
                    <Text className={styles.cardValue}>{pendingLeaves}</Text>
                </div>
                <div className={styles.card}>
                    <img src="https://cdn.hubblecontent.osi.office.net/m365content/publish/81eebd8e-b77e-4e7f-92b0-5315fea8ac47/thumbnails/xxlarge.jpg" alt="Approved Leaves" className={styles.cardImage} />
                    <Text className={styles.cardTitle}>Approved</Text>
                    <Text className={styles.cardValue}>{approvedLeaves}</Text>
                </div>
                <div className={styles.card}>
                    <img src="https://cdn.hubblecontent.osi.office.net/m365content/publish/8e851884-e5d2-4d5e-9b55-8d9197b22733/thumbnails/xxlarge.jpg" alt="Rejected Leaves" className={styles.cardImage} />
                    <Text className={styles.cardTitle}>Rejected</Text>
                    <Text className={styles.cardValue}>{rejectedLeaves}</Text>
                </div>
            </div>

            {/* Dashboard Charts */}
            <div className={styles.dashboardContainer}>
                <div className={styles.chartCard}>
                    <Text weight="semibold" size={400} block>Leave Types Distribution</Text>
                    <svg ref={typeChartRef}></svg>
                </div>
                <div className={styles.chartCard}>
                    <Text weight="semibold" size={400} block>Leave Status Distribution</Text>
                    <svg ref={statusChartRef}></svg>
                </div>
            </div>

            {/* Filters and Grid */}
            <div className={styles.mainContent}>
                <div className={styles.filterBar}>
                    <Dropdown value={statusFilter ? statusOptions.find(o => o.value.toString() === statusFilter)?.label : "All Statuses"} onOptionSelect={(_, d) => setStatusFilter(d.optionValue || "")}>
                        <Option value="">All Statuses</Option>
                        {statusOptions.map(opt => <Option key={opt.value} value={opt.value.toString()}>{opt.label}</Option>)}
                    </Dropdown>
                    <Dropdown value={typeFilter ? typeOptions.find(o => o.value.toString() === typeFilter)?.label : "All Types"} onOptionSelect={(_, d) => setTypeFilter(d.optionValue || "")}>
                        <Option value="">All Types</Option>
                        {typeOptions.map(opt => <Option key={opt.value} value={opt.value.toString()}>{opt.label}</Option>)}
                    </Dropdown>
                    <Button appearance="secondary" onClick={handleDownloadCSV}>Download CSV</Button>
                    <Button appearance="primary" className={styles.addButton} icon={<AddRegular />} onClick={() => { setIsDialogOpen(true); setEditingLeaveId(null); }}>Apply Leave</Button>
                </div>

                <div className={styles.gridContainer}>
                    <DataGrid items={leaveData} columns={columns} getRowId={(item) => item.cr4f0_leavemanagementid} focusMode="composite">
                        <DataGridHeader>
                            <DataGridRow>{({ renderHeaderCell }) => <DataGridHeaderCell>{renderHeaderCell()}</DataGridHeaderCell>}</DataGridRow>
                        </DataGridHeader>
                        <DataGridBody>
                            {({ item }) => (
                                <DataGridRow key={item.cr4f0_leavemanagementid}>
                                    {({ renderCell }) => <DataGridCell>{renderCell(item)}</DataGridCell>}
                                </DataGridRow>
                            )}
                        </DataGridBody>
                    </DataGrid>
                </div>
            </div>

            {/* Add/Edit Dialog */}
            <Dialog open={isDialogOpen} onOpenChange={(_, data) => setIsDialogOpen(data.open)}>
                <DialogSurface>
                    <DialogBody>
                        <DialogTitle>{editingLeaveId ? "Edit Leave" : "Add New Leave"}</DialogTitle>
                        <DialogContent>
                            <div className={styles.formField}>
                                <Text weight="semibold" size={300}>Leave Name</Text>
                                <Input aria-label="Leave Name" value={formData.cr4f0_leavemanagement1} onChange={(_, d) => setFormData({ ...formData, cr4f0_leavemanagement1: d.value })} />
                            </div>
                            <div className={styles.formField}>
                                <Text weight="semibold" size={300}>Reason</Text>
                                <Input aria-label="Reason" value={formData.cr4f0_leavereason} onChange={(_, d) => setFormData({ ...formData, cr4f0_leavereason: d.value })} />
                            </div>
                            <div className={styles.formField}>
                                <Text weight="semibold" size={300}>Leave Type</Text>
                                <Dropdown placeholder="Select Leave Type" value={typeOptions.find(opt => opt.value === formData.cr4f0_leavetype)?.label || ""} onOptionSelect={(_, d) => setFormData({ ...formData, cr4f0_leavetype: parseInt(d.optionValue || "810760000") })}>
                                    {typeOptions.map(opt => (<Option key={opt.value} value={opt.value.toString()}>{opt.label}</Option>))}
                                </Dropdown>
                            </div>
                            <div className={styles.formField}>
                                <Text weight="semibold" size={300}>Leave Start Date</Text>
                                <input
                                    type="date"
                                    value={formatDateForInput(formData.cr4f0_leavestartdate)}
                                    onChange={(e) => setFormData({ ...formData, cr4f0_leavestartdate: new Date(e.target.value) })}
                                />
                            </div>
                            <div className={styles.formField}>
                                <Text weight="semibold" size={300}>Leave End Date</Text>
                                <input
                                    type="date"
                                    value={formatDateForInput(formData.cr4f0_leaveenddate)}
                                    onChange={(e) => setFormData({ ...formData, cr4f0_leaveenddate: new Date(e.target.value) })}
                                />
                            </div>
                            <div className={styles.formField}>
                                <Text weight="semibold" size={300}>Upload Supporting Document</Text>
                                <div className={styles.fileUploadContainer}>
                                    <input type="file" accept=".pdf,.jpg,.jpeg,.png" ref={fileInputRef} style={{ display: "none" }} onChange={handleFileUpload} />
                                    <Button appearance="primary" onClick={() => fileInputRef.current?.click()}>Upload Document</Button>
                                    {uploadedFile && (
                                        <div className={styles.uploadedFile}>
                                            <Text size={300}>{uploadedFile.name}</Text>
                                            <Button appearance="subtle" onClick={handleRemoveFile}>Remove</Button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </DialogContent>
                        <DialogActions>
                            <Button appearance="secondary" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                            <Button appearance="primary" onClick={handleAddOrUpdateLeave}>{editingLeaveId ? "Update" : "Save"}</Button>
                        </DialogActions>
                    </DialogBody>
                </DialogSurface>
            </Dialog>

            {/* Delete Confirmation Dialog */}
            <Dialog open={isDeleteConfirmDialogOpen} onOpenChange={(_, data) => setIsDeleteConfirmDialogOpen(data.open)}>
                <DialogSurface>
                    <DialogBody>
                        <DialogTitle>Confirm Deletion</DialogTitle>
                        <DialogContent>
                            <Text weight="semibold" size={300}>Are you sure you want to delete this leave request?</Text>
                        </DialogContent>
                        <DialogActions>
                            <Button appearance="secondary" onClick={() => setIsDeleteConfirmDialogOpen(false)}>Cancel</Button>
                            <Button appearance="primary" onClick={confirmDelete}>Confirm</Button>
                        </DialogActions>
                    </DialogBody>
                </DialogSurface>
            </Dialog>

            {/* Delete Success Dialog */}
            <Dialog open={isDeleteSuccessDialogOpen} onOpenChange={(_, data) => setIsDeleteSuccessDialogOpen(data.open)}>
                <DialogSurface>
                    <DialogBody>
                        <DialogTitle>Success</DialogTitle>
                        <DialogContent>
                            <Text weight="semibold" size={300}>Leave has been deleted successfully.</Text>
                        </DialogContent>
                        <DialogActions>
                            <Button appearance="primary" onClick={() => setIsDeleteSuccessDialogOpen(false)}>OK</Button>
                        </DialogActions>
                    </DialogBody>
                </DialogSurface>
            </Dialog>
        </div>
    );
};

export default GeneratedComponent;